#!/bin/bash

# USB/IP
apt-get install usbip
echo "usbip-core" >> /etc/modules
echo "usbip-host" >> /etc/modules
cp -p ./scripts/usbipd /etc/init.d/usbipd
update-rc.d usbipd defaults

# RemCypr
cp -p ./rem_cyprd /usr/sbin/rem_cyprd
cp -p ./scripts/rem_cyprd /etc/init.d/rem_cyprd
update-rc.d rem_cyprd defaults

